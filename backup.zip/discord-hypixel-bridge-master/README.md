# discord-hypixel-bridge
Bridges a Discord channel chat with Hypixel Guild Chat.  
Extremely WIP (Currently doesn't do anything).

## Usage
**TODO**
